$(document).ready(function(){
	
	
  $(".mySlider").owlCarousel({
	  items: 1,
	  loop: true,
	  nav: true,
	  navText: ['','']
  });
	
	
	var itemBg = $('.itemBg');
	
	
	$('.mySlider .singleSlide').each(function(){
		var itmeImg = $(this).find('.itemBg img').attr('src');
		$(this).css({
			background: 'url(' + itmeImg + ')'
		});
	});
	
	function mySlideFunc(){
	
		$('.owl-item').removeClass('next prev');
		
		var currenSlide = $('.mySlider .owl-item.active');
		currenSlide.next('.owl-item').addClass('next');
		currenSlide.prev('.owl-item').addClass('prev');

		var nextSlideImg = $('.owl-item.next').find('.itemBg img').attr('src');
		var prevSlideImg = $('.owl-item.prev').find('.itemBg img').attr('src');

		$('.owl-nav .owl-prev').css({
			background: 'url(' + prevSlideImg + ')'
		})

		$('.owl-nav .owl-next').css({
			background: 'url(' + nextSlideImg + ')'
		})
	
	}
	
	mySlideFunc();
	
	$(".mySlider").on('translated.owl.carousel', function(){
		mySlideFunc();
	});
	
	
	$(".mySlider").on('translate.owl.carousel', function(){
		$('.singleSlide h1').removeClass('bounceIn animated').hide();
		$('.singleSlide p').removeClass('slideInRight animated').hide();
		$('.singleSlide .btn').removeClass('slideInRight animated').hide();
	});	
	
	$(".mySlider").on('translated.owl.carousel', function(){
		$('.owl-item.active .singleSlide h1').addClass('bounceIn animated').show();
		$('.owl-item.active .singleSlide p').addClass('slideInRight animated').show();
		$('.owl-item.active .singleSlide .btn').addClass('slideInRight animated').show();
	});
	
	
	
	
});